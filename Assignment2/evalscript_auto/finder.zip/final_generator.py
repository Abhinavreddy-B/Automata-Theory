import subprocess

subprocess.call(['python3','temp.py'])
subprocess.call(['python3','max.py'])